using System;
using System.Collections.Generic;
using System.Text;
using AjaxDemo.DataObjects;

namespace AjaxDemo.DataLayer
{
    public class Products
    {
        public static ProductInfo Get(int productID)
        {
            switch (productID)
            {
                case 1:
                    return new ProductInfo(
                        1, "Hot Fuss",
                        "The Killers might hail from one of the USA's most quintessentially American cities (Las Vegas), but their debut album Hot Fuss displays an Anglophilic streak that is an ocean wide. Steeped in the back-catalogue of the Smiths and Pulp...",
                        (decimal)14.99);
                case 2:
                    return new ProductInfo(
                        2, "The Godfather",
                        "Despite making many other distinguished films in his long, wandering career, Francis Ford Coppola will always be known as the man who directed The Godfather trilogy, a series that has dominated and defined their creator in a way perhaps no other director can understand. ",
                        (decimal)15.99);
                case 3:
                    return new ProductInfo(
                        3, "Visual Studio 2003",
                        "Visual Studio .NET Pro 2003 is Microsoft's multi-faceted development tool, targeting both Windows and Web applications. This 2003 edition includes numerous small improvements as well as major new features such as the Compact Framework for applications that run on Pocket PC and other smart devices.",
                        (decimal)600.00);
                default:
                    return null;
            }
        }
        public static List<ProductInfo> GetAll()
        {
            List<ProductInfo> list = new List<ProductInfo>();
            list.Add(Get(1));
            list.Add(Get(2));
            list.Add(Get(3));

            return list;
        }
    }
}
