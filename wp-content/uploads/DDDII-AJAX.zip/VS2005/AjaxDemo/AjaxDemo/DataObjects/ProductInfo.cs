using System;
using System.Collections.Generic;
using System.Text;

namespace AjaxDemo.DataObjects
{
    public class ProductInfo
    {
        public ProductInfo(int productID, string name, string description, decimal price)
        {
            this._name = name;
            this._description = description;
            this._price = price;
            this._productID = productID;
        }

        private string _description;

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
	
        private int _productID;

        public int ProductID
        {
            get { return _productID; }
            set { _productID = value; }
        }

        private decimal _price;

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }

        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }


    }
}
