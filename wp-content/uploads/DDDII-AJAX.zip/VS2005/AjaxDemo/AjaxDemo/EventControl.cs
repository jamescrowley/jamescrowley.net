using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;

namespace AjaxDemo
{
    // Idea stolen with thanks to Rick Strahl - http://west-wind.com/weblog/

    public delegate string ScriptCallbackHandler(string eventArgument);

    public class EventControl : Control, ICallbackEventHandler
    {
        public event ScriptCallbackHandler ScriptCallback;

        string _eventArgument;

        public string GetCallbackResult()
        {
            return this.ScriptCallback(_eventArgument);
        }

        public void RaiseCallbackEvent(string eventArgument)
        {
            _eventArgument = eventArgument;
        }
    }
}
