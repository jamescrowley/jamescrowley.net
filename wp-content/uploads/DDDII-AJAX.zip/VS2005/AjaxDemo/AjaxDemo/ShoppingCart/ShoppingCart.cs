using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxDemo.DataObjects;

namespace AjaxDemo.ShoppingCart
{

    public class ShoppingCart : WebControl //, ICallbackEventHandler
    {
	
	
        public ShoppingCart() : base(HtmlTextWriterTag.Ul) {}

        public List<ProductInfo> Items
        {
            get
            {
                if (Page.Session["ShoppingCartItems"] == null)
                    Page.Session["ShoppingCartItems"] = new List<ProductInfo>();

                return (List<ProductInfo>)Page.Session["ShoppingCartItems"];
            }
            set { Page.Session["ShoppingCartItems"] = value; }
        }

        protected override void RenderChildren(HtmlTextWriter writer)
        {
            decimal totalPrice = 0;
            if (Items.Count == 0)
            {
                // shopping cart is empty
                writer.Write("<li>No Items</li>");
            }
            else
            {
                int index = 0;
                foreach (ProductInfo item in Items)
                {
                    
                    // render the shopping cart item
                    writer.WriteFullBeginTag("li");
                    writer.Write(item.Name + " - " + String.Format("{0:c}", item.Price));
                    writer.WriteEndTag("li");
                    // calculate the total price
                    totalPrice += item.Price;
                    index++;
                }
            }
            
            // render the order total
            writer.WriteFullBeginTag("p");
            writer.Write("Total: " + String.Format("{0:c}", totalPrice));
            writer.WriteEndTag("p");
        }

        

        /*
        public string RaiseCallbackEvent(string eventArgument)
        {
            int index = Int32.Parse(eventArgument);
            if (Items.Count > index) 
                // remove the item
                Items.RemoveAt(index);
            return RenderToString();
        
        }
        writer.Write("[<a href=\"#\" onclick=\"" + Page.ClientScript.GetCallbackEventReference(
                        this, "'" + index.ToString() + "'", "onCallback", "'RemoveItem'", "onCallbackError", true) + "\">Remove</a>]");
         * 
         * 
         * 
         */
    }
}
