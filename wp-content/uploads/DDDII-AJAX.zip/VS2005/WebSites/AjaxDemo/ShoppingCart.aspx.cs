using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.UI;
using AjaxDemo.ShoppingCart;
using AjaxDemo.DataLayer;
using AjaxDemo.DataObjects;

public partial class ShoppingCart_aspx : Page, ICallbackEventHandler
{
    void Page_Load(object sender, EventArgs e)
    {
        // attach event handlers
        ShoppingCartList.ItemDataBound += new System.Web.UI.WebControls.RepeaterItemEventHandler(ShoppingCartList_ItemDataBound);

        if (!IsPostBack)
        {
            // list the products available
            AvailableProducts.DataSource = Products.GetAll();
            AvailableProducts.DataBind();
            // load the initial shopping list and display it
            List<ProductInfo> list = LoadShoppingList();
            UpdateShoppingDisplay(list);
        }
        
    }

    decimal _runningTotal = 0;

    /// <summary>
    /// Adds up the items in the shopping cart as we bind to it
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void ShoppingCartList_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
    {
        _runningTotal += ((ProductInfo)e.Item.DataItem).Price;
    }

    /// <summary>
    /// Fetches the list of products from the users session
    /// </summary>
    /// <returns></returns>
    List<ProductInfo> LoadShoppingList()
    {
        // get the list of products
        if (Page.Session["ShoppingCartItems"] == null)
            Page.Session["ShoppingCartItems"] = new List<ProductInfo>();

        return (List<ProductInfo>)Page.Session["ShoppingCartItems"];
    }

    /// <summary>
    /// Updates the shopping list controls with the specified product list
    /// </summary>
    /// <param name="list"></param>
    void UpdateShoppingDisplay(List<ProductInfo> list)
    {
        // bind the shopping cart list
        ShoppingCartList.DataSource = list;
        ShoppingCartList.DataBind();
        // update the total
        ShoppingCartTotal.Text = String.Format("{0:c}", _runningTotal);
    }

    int _callbackProductID;
    string _callbackMethod;

    public void RaiseCallbackEvent(string eventArgument)
    {
        String[] arguments = eventArgument.Split(':');
        _callbackMethod = arguments[0];
        _callbackProductID = Int32.Parse(arguments[1]);
    }

    public string GetCallbackResult()
    {
        // fetch the current list, and add this item to it
        List<ProductInfo> list = LoadShoppingList();
        switch (_callbackMethod)
        {
            case "AddItem":
                // fetch the product - we're given the product ID
                ProductInfo pi = Products.Get(_callbackProductID);
                list.Add(pi);
                break;
            case "RemoveItem":
                // fetch the current list, and remove the item at
                // the correct index
                list.RemoveAt(_callbackProductID);
                break;
        }
        // update the list control
        UpdateShoppingDisplay(list);
        // render the portion we're interested in
        return RenderControlToString(ShoppingCart);
    }

    public string RenderControlToString(Control c)
    {
        // render the result
        using (StringWriter sw = new StringWriter())
        {
            using (HtmlTextWriter writer = new HtmlTextWriter(sw))
            {
                c.RenderControl(writer);
            }
            return sw.ToString();
        }
    }
}
