using System;
using System.Web;
using System.Text;
using System.IO;
using NanoBriq.Colorizer.Core;
//using SourceCodeIndexer.SyntaxHighlighting;
namespace AjaxDemo
{
	/// <summary>
	/// Summary description for ColourUtility.
	/// </summary>
	public class ColourUtility
	{
		public static string ColourCode(string code)
		{
			
			using(MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(code)))
			{
				Scanner.Init(ms);
				Parser.Reset();
				Parser.Parse();
				if(0 == Errors.count)
					return Parser.Colorized;
				else
					return String.Format(@"Parse complete -- {0} error(s) detected", Errors.count);
			}
		}
	}
}
