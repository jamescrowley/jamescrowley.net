using System;
using System.Collections;
using System.Text;

namespace AjaxDemo
{
	public class Products
	{
		public static ProductInfo Get(int productID)
		{
			switch (productID)
			{
				case 1:
					return new ProductInfo(
						1, "Hot Fuss",
						"The Killers might hail from one of the USA's most quintessentially American cities (Las Vegas), but their debut album Hot Fuss displays an Anglophilic streak that is an ocean wide. Steeped in the back-catalogue of the Smiths and Pulp...",
						(decimal)14.99);
				case 2:
					return new ProductInfo(
						2, "The Godfather",
						"Despite making many other distinguished films in his long, wandering career, Francis Ford Coppola will always be known as the man who directed The Godfather trilogy, a series that has dominated and defined their creator in a way perhaps no other director can understand. ",
						(decimal)15.99);
				case 3:
					return new ProductInfo(
						3, "Visual Studio 2003 Professional",
						"Visual Studio .NET Pro 2003 is Microsoft's multi-faceted development tool, targeting both Windows and Web applications. This 2003 edition includes numerous small improvements as well as major new features such as the Compact Framework for applications that run on Pocket PC and other smart devices.",
						(decimal)600.00);
				case 4:
					return new ProductInfo(
						4, "Visual Studio 2003 Standard",
						(decimal)800.00);
				case 5:
					return new ProductInfo(
						5, "Visual InterDev",
						(decimal)600.00);
				case 6:
					return new ProductInfo(
						6, "Visual Studio 2005 Standard",
						(decimal)300.00);
				case 7:
					return new ProductInfo(
						7, "Visual Studio 2005 Professional",
						(decimal)800.00);

				default:
					return null;
			}
		}

		public static ArrayList GetSearchResults(string query) 
		{
			ArrayList products = GetAll();
			ArrayList results = new ArrayList();

			query = query.ToLower();

			foreach(ProductInfo pi in products)
				if (pi.Name.ToLower().StartsWith(query))
					results.Add(pi);

			return results;
		}

		public static ArrayList GetAll()
		{
			ArrayList list = new ArrayList();
			for(int i=1; i<8; i++)
				list.Add(Get(i));

			return list;
		}
	}
}
