using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace AjaxDemo
{
	public class AddressDemo : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox Name;
		protected System.Web.UI.WebControls.TextBox houseNumber;
		protected System.Web.UI.WebControls.TextBox postCode;
		protected System.Web.UI.WebControls.TextBox AddressLine1;
		protected System.Web.UI.WebControls.TextBox City;
		protected System.Web.UI.WebControls.TextBox County;
		protected System.Web.UI.WebControls.TextBox Password;
		protected System.Web.UI.WebControls.TextBox PasswordConfirm;
		protected System.Web.UI.WebControls.Button Button1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// register type
			Ajax.Utility.RegisterTypeForAjax(typeof(AddressDemo));

			Button1.Attributes.Add("onclick",
				@"if (document.getElementById('AddressLine1').value == 'Please wait...') { alert('Please wait for address call to finish'); return false; }");
		}

		[Ajax.AjaxMethod]
		public Address FetchAddress(string houseNumber, string postCode)
		{
			System.Threading.Thread.Sleep(1000);
			if (postCode.StartsWith("N"))
				return new Address("56","Holloway Road", "Islington", "N19 2PX", "London");
			else
				// return the address
				return new Address("128","Sandringham Close", "Enfield", "EN3 2PX", "Middlesex");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("AddressComplete.aspx");
		}
	}
}
