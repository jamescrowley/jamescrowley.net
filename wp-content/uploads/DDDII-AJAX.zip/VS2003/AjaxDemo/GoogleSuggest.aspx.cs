using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace AjaxDemo
{
	public class GoogleSuggest : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Search;
		protected System.Web.UI.WebControls.Label SearchResults;
		protected System.Web.UI.WebControls.TextBox Name;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// register type
			Ajax.Utility.RegisterTypeForAjax(typeof(GoogleSuggest));
		}

		[Ajax.AjaxMethod]
		public ArrayList GetSuggestions(string search) 
		{
			return Products.GetSearchResults(search);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		private void InitializeComponent()
		{    
			this.Search.Click += new System.EventHandler(this.Search_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Search_Click(object sender, System.EventArgs e)
		{
			SearchResults.Visible = true;
		}


	}
}
