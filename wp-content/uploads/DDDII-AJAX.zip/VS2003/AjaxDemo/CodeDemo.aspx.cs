using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Ajax;
namespace AjaxDemo
{
	public class CodeDemo : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox codeInput;

		private void Page_Load(object sender, System.EventArgs e)
		{
			Ajax.Utility.RegisterTypeForAjax(typeof(CodeDemo));
		}

		static int progressVal;

		[AjaxMethod]
		public string ColourCode(string code) 
		{
			progressVal = 0;
			System.Threading.Thread.Sleep(800);
			progressVal = 25;
			System.Threading.Thread.Sleep(800);
			progressVal = 50;
			System.Threading.Thread.Sleep(800);
			progressVal = 75;
			System.Threading.Thread.Sleep(800);
			progressVal = 100;
			return ColourUtility.ColourCode(code);
		}

		[AjaxMethod]
		public int CheckProgress() 
		{
			return progressVal;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
